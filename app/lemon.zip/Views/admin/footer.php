</div>
</div>
<div class="modal" data-easein="flipYIn" id="posModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"></div>

<div id="popUpView"></div>
<footer class="footer-content">
    <div class="footer-text d-flex align-items-center justify-content-between">
        <div class="copy"><?php echo esc($settings->footer_text); ?></div> 
    </div>
</footer>
<!--/.footer content-->
<div class="overlay"></div>
<!--Global script(used by all pages)-->

<script src="<?php echo base_url("public/assets/dist/js/popper.min.js") ?>"></script>
<script src="<?php echo base_url("public/assets/plugins/bootstrap/js/bootstrap.min.js") ?>"></script>
<script src="<?php echo base_url("public/assets/plugins/metisMenu/metisMenu.min.js") ?>"></script>
<script src="<?php echo base_url("public/assets/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js") ?>"></script>
<script src="<?php echo base_url("public/assets/dist/js/sidebar.js?v=2.1") ?>"></script>
<script src="<?php echo base_url("public/assets/js/custom.js") ?>" type="text/javascript"></script> 
<script src="<?php echo base_url("public/assets/js/web3.min.js") ?>" type="text/javascript"></script>
  
</div>