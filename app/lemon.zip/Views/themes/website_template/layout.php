<?php echo (!empty($content) ? $content : null);
