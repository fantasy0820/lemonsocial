


 

 <div class="card">
        <div class="align-items-center card-body d-flex ji justify-content-center empty-tag">
            <blockquote class="blockquote mb-0">
              <h4 class="text-center text-primary">
                  <a class="nav-link" href="javascript:;" id="connect_wallet"><img width="30px" src="<?php echo base_url('public/assets/images/icons/metamask.png'); ?>"><?php echo display('Connect'); ?></a>
              </h4> 
            </blockquote>
        </div>
    </div>