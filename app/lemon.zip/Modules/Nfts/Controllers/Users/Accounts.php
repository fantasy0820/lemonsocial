<?php 
namespace App\Modules\Nfts\Controllers\Users;
class Accounts extends BaseController 
{
	
	  
}