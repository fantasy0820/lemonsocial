<?php
 
    $ADMINMENU['cms'] = array(
        'order'         => 13,
        'parent'        => display('Content Manager'),
        'status'        => 0,
        'link'          => 'content_manager/cms',
        'icon'          => '<i class="fas fa-tv"></i>',
        'segment'       => 3,
        'segment_text'  => 'cms'
    );